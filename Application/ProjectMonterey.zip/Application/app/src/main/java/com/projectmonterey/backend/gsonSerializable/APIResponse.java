package com.projectmonterey.backend.gsonSerializable;

public class APIResponse {
    public int code;
    public String status;
    public String message;
}
